// function to send email to anyone's email that is entered in the text box
function forgotPassword(){
    var userEmail = document.getElementById("forgotEmail").value;
	
    Email.send({
        Host : "smtp.gmail.com",
        //replace with own email and password 
        Username : "sender username",
        Password : "sender password",
        To : userEmail,
        From : "sender",
        Subject : "Reset password",
        Body : "Reset your password"+
                "<a href='http://127.0.0.1:8080/resetPassword.html'>Click here</a>"
    }).then(
        message => alert(message)
    );
}