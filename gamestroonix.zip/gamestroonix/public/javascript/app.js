//display game for platforms
var game_url = "/game";
var game_array = []; // This creates an empty game array
var gameCount = 0;
var platform = "PC"; //set main platform to load
var catergory = "Latest";//set main category to load
var currentIndex = 0;
var currentIndexCategory = 0;

//display shops
var shop_url = "/shop";
var shop_array = []; // This creates an empty shop array
var shopCount = 0;

//display videos
var video_url = "/video";
var video_array = []; // This creates an empty video array
var videoCount = 0;
var currentIndexVideo = 0;

//display comments
var comment_url = "/comment";
var comment_array = []; // This creates an empty comment array

//display profiles
var profile_url = "/profile";
var profile_array = []; // This creates an empty profile array

//display review count
var profileReviewCount_url = "/profile";
var profileReviewCount_array = []; //This creates an empty review count array

var profileComments_url = "/profile/showComments";
var profileComments_array = []; //This creates an empty recent comments array
